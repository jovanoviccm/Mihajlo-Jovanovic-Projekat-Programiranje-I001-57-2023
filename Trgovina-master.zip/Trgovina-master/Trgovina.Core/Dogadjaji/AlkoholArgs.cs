﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trgovina.Core.Dogadjaji
{
    public class AlkoholArgs
    {
        public string NazivArtikla { get; set; }
        public DateTime VrijemePokusaja { get; set; }
    }
}
